<?
	include "/space/portal/php/portal.php3";

	$IsAdmin = get_is_admin($auth_server_con);

	if ($IsAdmin != "YES")
	{
		header("Location: admin_not_admin_error.html");
	}
	else
	{
		$Result[100];

//		$Result = exec("grep ADMIN_NEW_PLAYER /space/space/game/log/systemlog", $Array);
		$Result = exec("ls -al");

		echo "Result : (".$Result.")";
	}
?>

