<?
	readfile($LOG_URL);
?>

